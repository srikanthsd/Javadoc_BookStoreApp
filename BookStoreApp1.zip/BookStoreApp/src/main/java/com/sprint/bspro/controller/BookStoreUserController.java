package com.sprint.bspro.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sprint.bspro.dto.LoginDTO;
import com.sprint.bspro.dto.ResetPasswordDTO;
import com.sprint.bspro.entity.MailStructure;
import com.sprint.bspro.service.EmailServiceImpl;
import com.sprint.bspro.service.IBookStoreUserService;
@CrossOrigin
@RestController
@RequestMapping("/login")
public class BookStoreUserController {
	static int otp;
	@Autowired
	IBookStoreUserService bookStoreUserService;
	
	@Autowired 
	private EmailServiceImpl emailService;
	
	
	/** * Validates a user's login credentials.
	 * 
	 * @param login The LoginDTO containing the user's login information.
	 * @return The LoginDTO with the user's role set after validation.
	 */
	@PostMapping("/check")
	public LoginDTO validateUser(@Valid @RequestBody LoginDTO login) {
		System.out.println("In post check login");
		String s =  bookStoreUserService.appLogin(login.getUsername(), login.getPassword());
		System.out.println(s+"-----------------");
		login.setRole(s);
		return login;
	}
	/** * Validates a user's username.
	 * 
	 * @param login The LoginDTO containing the user's login information.
	 * @return The LoginDTO with the username validation result and email set if the username exists.
	 */
	
	@PostMapping("/check/username")
	public LoginDTO validateUserName(@Valid @RequestBody LoginDTO login) {
		System.out.println("In post check login");
		String s =  bookStoreUserService.appCheckUser(login.getUsername());
		System.out.println(s+"-----------------");
		if(s!=null) {
			login.setIsUsername(true);
			login.setEmail(s);
		}
		return login;
	}
	/** * Sends an email using the provided MailStructure object.
	 * 
	 * @param details The MailStructure object containing the email details.
	 * @return The status of the email sending operation.
	 */
	
	@PostMapping("/sendmail")
    public String sendMail(@Valid @RequestBody MailStructure details)
    {
		System.out.println("email sent");
		otp = (int)(Math.random()*1000000);
		details.setSubject("OTP to set password for BOOK STORE APP");
		details.setMsgBody("Please Enter this OTP to change your Password "+otp);
        String status
            = emailService.sendSimpleMail(details);
 
        return status;
    }
	/** * Resets the password for a user based on the provided ResetPasswordDTO.
	 * 
	 * @param resetPassword The ResetPasswordDTO containing the user's reset password information.
	 * @return True if the OTP (One-Time Password) matches and the password is successfully updated, false otherwise.
	 */
	@PutMapping("/changepassword")
	public Boolean resetPassword(@Valid @RequestBody ResetPasswordDTO resetPassword ) {
		String otpstr = otp + "";
		if(resetPassword.getOtp().equals(otpstr)) {
			boolean check = bookStoreUserService.appUpdatePassword(resetPassword.getPassword(), resetPassword.getUsername());
			otp = (int)(Math.random()*1000000);
			return check;
		}
		otp = (int)(Math.random()*1000000);
		return false;
	}
}
